#pragma once
int oniX=500;
int oniY=450;
int jikiX = 200;
int jikiY = 500;
int jikivelX = 10;
int jikivelY = 0;
int jumpheight = 15;
int jumpcount = 0;
int sepalateX=0;
int sepalateY=0;

int mapsize = 32;

int hitTime = 0;
int bustercount = 0;
int sepalate = 30;


const int effect = 300;
int bloodX[effect]{0};
int bloodY[effect]{0};
int bloodvelX[effect]{0};
int bloodvelY[effect]{0};
int randamX[effect] = {0}; 
int randamY[effect] = {0};
int splashX = 26;
int splashY = 60;
int radius = 8;